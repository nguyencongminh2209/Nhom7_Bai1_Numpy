import menu

def main():
    menu.Menu()

if __name__ == '__main__':
    main()